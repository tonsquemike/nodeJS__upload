var express = require('express');
var app = express();
var path = require('path');
var formidable = require('formidable');
var fs = require('fs');

var files = ["", ""];
var fileIndex;

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', function(req, res){
  res.sendFile(path.join(__dirname, 'views/index.html'));
});

app.get('/download', function(req, res){
  console.log("call jar from here");
    var exec = require('child_process').exec;
    var child = exec('java -jar ejemploComponente.jar 45 10',
    function (error, stdout, stderr){
      console.log('Output -> ' + stdout);
      if(error !== null){
        console.log("Error -> "+error);
      }
    });
    module.exports = child;
  var file = files[0];
  res.download(file);
  //res.end();
});

app.post('/upload', function(req, res){
  fileIndex = 0;
  // create an incoming form object
  var form = new formidable.IncomingForm();

  // specify that we want to allow the user to upload multiple files in a single request
  form.multiples = true;

  // store all uploads in the /uploads directory

  form.uploadDir = path.join(__dirname, '/uploads');

  // every time a file has been uploaded successfully,
  // rename it to it's orignal name
  form.on('file', function(field, file) {
    fs.rename(file.path, path.join(form.uploadDir, file.name));
    files[fileIndex] = form.uploadDir+"/"+file.name;
    fileIndex++;
     
  });

  // log any errors that occur
  form.on('error', function(err) {
    console.log('An error has occured: \n' + err);
  });

  // once all the files have been uploaded, send a response to the client
  form.on('end', function() {
    console.log("file. 1"+files[0]);
    console.log("file. 2"+files[1]);

    //var file = files[0];
    //res.download(file); // Set disposition and send it.
    res.end('success');
  });

  // parse the incoming request containing the form data
  form.parse(req);

  
});

var server = app.listen((process.env.PORT || 5000), function(){
  console.log('listening on *:5000');
});
//tonsquemike